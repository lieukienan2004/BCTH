<?php
$basePath = defined('BASE_PATH') ? BASE_PATH : '';
$adminInitial = mb_strtoupper(mb_substr($_SESSION['full_name'] ?? 'A', 0, 1, 'UTF-8'), 'UTF-8');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý đề tài | TVU Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script>tailwind.config = { theme: { extend: { fontFamily: { 'inter': ['Inter', 'sans-serif'] } } } }</script>
    <style>* { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="font-inter bg-gradient-to-br from-slate-100 via-amber-50/30 to-orange-50/30 min-h-screen">

<?php include_once __DIR__ . '/../layouts/admin_sidebar.php'; ?>

<main class="lg:ml-72 min-h-screen">
    <header class="sticky top-0 z-30 bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 px-6 py-4 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
        <div class="relative z-10 flex items-center justify-between">
            <div class="text-white">
                <div class="flex items-center gap-2 mb-1"><span class="text-xl">📚</span><h2 class="text-xl font-bold">Quản lý đề tài</h2></div>
                <p class="text-white/80 text-sm">Duyệt và quản lý đề tài đồ án</p>
            </div>
        </div>
    </header>

    <div class="p-6 lg:p-8">
        <?php if (isset($_SESSION['success'])): ?>
        <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl flex items-center gap-3">
            <i class="bi bi-check-circle-fill text-green-500 text-xl"></i>
            <p class="text-green-700"><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <?php
            $pending = count(array_filter($data['topics'] ?? [], fn($t) => $t['status'] === 'pending'));
            $approved = count(array_filter($data['topics'] ?? [], fn($t) => $t['status'] === 'approved'));
            $rejected = count(array_filter($data['topics'] ?? [], fn($t) => $t['status'] === 'rejected'));
            ?>
            <div class="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl flex items-center justify-center">
                        <i class="bi bi-clock-history text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-2xl font-bold text-gray-800"><?= $pending ?></p>
                        <p class="text-sm text-gray-500">Chờ duyệt</p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                        <i class="bi bi-check-circle text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-2xl font-bold text-gray-800"><?= $approved ?></p>
                        <p class="text-sm text-gray-500">Đã duyệt</p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 bg-gradient-to-br from-red-500 to-rose-500 rounded-xl flex items-center justify-center">
                        <i class="bi bi-x-circle text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-2xl font-bold text-gray-800"><?= $rejected ?></p>
                        <p class="text-sm text-gray-500">Từ chối</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Topics Table -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-100">
                <h3 class="font-bold text-gray-800 flex items-center gap-2">
                    <i class="bi bi-journal-bookmark text-purple-500"></i>
                    Danh sách đề tài
                </h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">ID</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Đề tài</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Giảng viên</th>
                            <th class="px-6 py-4 text-center text-xs font-bold text-gray-600 uppercase">Slot</th>
                            <th class="px-6 py-4 text-center text-xs font-bold text-gray-600 uppercase">Trạng thái</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Ngày tạo</th>
                            <th class="px-6 py-4 text-center text-xs font-bold text-gray-600 uppercase">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (!empty($data['topics'])): ?>
                        <?php foreach ($data['topics'] as $topic): ?>
                        <tr class="hover:bg-purple-50/50 transition-all">
                            <td class="px-6 py-4">
                                <span class="w-8 h-8 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center font-bold text-sm"><?= $topic['topic_id'] ?></span>
                            </td>
                            <td class="px-6 py-4">
                                <p class="font-semibold text-gray-800"><?= htmlspecialchars($topic['title']) ?></p>
                                <p class="text-sm text-gray-500 line-clamp-1"><?= htmlspecialchars($topic['description'] ?? '') ?></p>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-2">
                                    <div class="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                                        <?= strtoupper(substr($topic['teacher_name'], 0, 1)) ?>
                                    </div>
                                    <span class="text-gray-700"><?= htmlspecialchars($topic['teacher_name']) ?></span>
                                </div>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <span class="px-3 py-1.5 bg-blue-100 text-blue-700 text-sm font-medium rounded-full">
                                    <?= $topic['current_students'] ?>/<?= $topic['max_students'] ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <?php
                                $statusColors = ['pending' => 'amber', 'approved' => 'green', 'rejected' => 'red'];
                                $statusNames = ['pending' => 'Chờ duyệt', 'approved' => 'Đã duyệt', 'rejected' => 'Từ chối'];
                                $color = $statusColors[$topic['status']] ?? 'gray';
                                ?>
                                <span class="px-3 py-1.5 bg-<?= $color ?>-100 text-<?= $color ?>-700 text-sm font-medium rounded-full">
                                    <?= $statusNames[$topic['status']] ?? $topic['status'] ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 text-gray-600"><?= date('d/m/Y', strtotime($topic['created_at'])) ?></td>
                            <td class="px-6 py-4">
                                <div class="flex items-center justify-center gap-2">
                                    <button onclick="openDetailModal(<?= htmlspecialchars(json_encode($topic)) ?>)" 
                                        class="p-2 bg-blue-100 hover:bg-blue-200 text-blue-600 rounded-lg transition-all" title="Xem">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <?php if ($topic['status'] === 'pending'): ?>
                                    <a href="<?= $basePath ?>/admin/approveTopic/<?= $topic['topic_id'] ?>" 
                                        class="p-2 bg-green-100 hover:bg-green-200 text-green-600 rounded-lg transition-all" title="Duyệt">
                                        <i class="bi bi-check-lg"></i>
                                    </a>
                                    <a href="<?= $basePath ?>/admin/rejectTopic/<?= $topic['topic_id'] ?>" 
                                        onclick="return confirm('Bạn có chắc muốn từ chối đề tài này?')"
                                        class="p-2 bg-red-100 hover:bg-red-200 text-red-600 rounded-lg transition-all" title="Từ chối">
                                        <i class="bi bi-x-lg"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center text-gray-400">
                                <i class="bi bi-inbox text-4xl mb-2"></i>
                                <p>Chưa có đề tài nào</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Detail Modal -->
<div id="detailModal" class="hidden fixed inset-0 z-50">
    <div class="absolute inset-0 bg-black/60 backdrop-blur-sm" onclick="closeDetailModal()"></div>
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <div class="bg-white rounded-3xl shadow-2xl overflow-hidden">
            <div class="bg-gradient-to-r from-purple-500 to-violet-500 p-6 relative">
                <button onclick="closeDetailModal()" class="absolute top-4 right-4 w-8 h-8 bg-white/20 hover:bg-white/40 rounded-full flex items-center justify-center text-white">
                    <i class="bi bi-x-lg"></i>
                </button>
                <h3 id="detailTitle" class="text-xl font-bold text-white pr-8"></h3>
            </div>
            <div class="p-6 space-y-4 max-h-[50vh] overflow-y-auto">
                <div class="flex items-center gap-4 p-4 bg-green-50 rounded-xl">
                    <div class="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center text-white font-bold" id="detailTeacherAvatar"></div>
                    <div>
                        <p class="text-sm text-gray-500">Giảng viên</p>
                        <p id="detailTeacher" class="font-semibold text-gray-800"></p>
                    </div>
                </div>
                <div class="p-4 bg-gray-50 rounded-xl">
                    <p class="text-sm text-gray-500 mb-2">Mô tả</p>
                    <p id="detailDesc" class="text-gray-700"></p>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="p-4 bg-blue-50 rounded-xl text-center">
                        <p class="text-sm text-gray-500">Số lượng</p>
                        <p id="detailSlot" class="font-bold text-gray-800"></p>
                    </div>
                    <div class="p-4 bg-amber-50 rounded-xl text-center">
                        <p class="text-sm text-gray-500">Trạng thái</p>
                        <p id="detailStatus" class="font-bold text-gray-800"></p>
                    </div>
                </div>
            </div>
            <div class="p-6 border-t border-gray-100">
                <button onclick="closeDetailModal()" class="w-full py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl transition-all">Đóng</button>
            </div>
        </div>
    </div>
</div>

<script>
function openDetailModal(topic) {
    document.getElementById('detailTitle').textContent = topic.title;
    document.getElementById('detailTeacher').textContent = topic.teacher_name;
    document.getElementById('detailTeacherAvatar').textContent = topic.teacher_name.charAt(0).toUpperCase();
    document.getElementById('detailDesc').textContent = topic.description || 'Không có mô tả';
    document.getElementById('detailSlot').textContent = topic.current_students + '/' + topic.max_students + ' sinh viên';
    const statusNames = {pending: 'Chờ duyệt', approved: 'Đã duyệt', rejected: 'Từ chối'};
    document.getElementById('detailStatus').textContent = statusNames[topic.status] || topic.status;
    document.getElementById('detailModal').classList.remove('hidden');
}
function closeDetailModal() {
    document.getElementById('detailModal').classList.add('hidden');
}
</script>

</body>
</html>
