    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= $basePath ?>/js/modal-fix.js"></script>
    <script src="<?= $basePath ?>/js/script.js"></script>
    <script src="<?= $basePath ?>/js/admin.js"></script>
</body>
</html>
