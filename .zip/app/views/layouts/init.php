<?php
// Helper file để định nghĩa basePath cho tất cả views
if (!isset($basePath)) {
    $basePath = defined('BASE_PATH') ? BASE_PATH : '';
}
