<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'php_cn');
define('DB_USER', 'root');
define('DB_PASS', '');

// Application configuration
define('BASE_URL', 'http://localhost/PHP-BCTH/public/');
define('APP_NAME', 'Quản lý Đồ án CNTT');

// Session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
